Ext.application({
    name: 'AM',
    requires: ["AM.proxy.AerialProxy"],

    appFolder: 'app',

    controllers: [
        "Users"
    ],

    launch: function()
    {
        Ext.create('Ext.container.Viewport', {
            layout: 'fit',
            items: [
                {
                    layout: "fit",
                    items: {
                        xtype: "userlist"
                    }
                }
            ]
        });
        
        var store = Ext.getStore("Users");
        store.getUsersLike(null, {firstName:"Danny", lastName:"Kopping"}, 200);
    }
});