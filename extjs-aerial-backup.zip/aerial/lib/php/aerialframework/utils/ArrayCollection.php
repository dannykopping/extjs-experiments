<?php
class ArrayCollection{
	public $_explicitType = "flex.messaging.io.ArrayCollection";
	public $source = array();

	function ArrayCollection(){
		$this->source = array();
	}
}
?>