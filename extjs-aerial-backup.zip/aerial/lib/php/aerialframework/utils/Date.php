<?php
	class Date
	{		
		public $time;
	}
?>