<?php
	class Encrypted
	{
		public $_explicitType = "org.aerialframework.encryption.EncryptedVO";

		// ByteArray containing encrypted data
		public $data;
		public $resetKey = false;
	}
?>