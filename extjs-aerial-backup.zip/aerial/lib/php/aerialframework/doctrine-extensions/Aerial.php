<?php

require_once 'Aerial/Core.php';

class Aerial extends Aerial_Core{


}