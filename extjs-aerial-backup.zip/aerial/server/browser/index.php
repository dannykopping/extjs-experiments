<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		
		<title>AMFPHP Service Browser</title>
		
		<style>
			body { margin: 0px; overflow:hidden }
		</style>
	
	</head>
	
	<script type="text/javascript" src="swfobject/swfobject.js"></script>
	
	<script type="text/javascript">
		var attributes = {id:"browser"};
		swfobject.embedSWF("browser.swf", "contentDiv", "100%", "100%", "0", "expressInstall.swf", null, null, attributes);
	</script>
	
	<body scroll="no">
		<div id="contentDiv" style="text-align: center; font-family: Tahoma">
			<p>You do not have the correct version of Flash installed. Please click <a href="http://get.adobe.com/flashplayer/">here</a> to download it.</p>
		</div>
	</body>
</html>