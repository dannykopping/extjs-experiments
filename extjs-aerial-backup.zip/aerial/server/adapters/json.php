<?php

    import('aerialframework.core.ConfigXml');
    import('aerialframework.core.Bootstrapper');
    import('aerialframework.core.AerialStartupManager');

    Bootstrapper::getInstance();

    global $args;

    validateArguments($args);

    $service = $args[0];
    $method = $args[1];
    $data = isset($_GET["data"]) ? $_GET["data"] : null;
    $data = json_decode($data);

    $servicesPath = ConfigXml::getInstance()->servicesPath;

    require_once($servicesPath."/$service.php");

    $serviceClass = new $service;
    $bob = call_user_func_array(array($service, $method), $data);

    echo json_encode($bob);

//    if(is_subclass_of($bob, "Doctrine_Collection") || is_a($bob, "Doctrine_Collection"))
//    {
//        echo json_encode($bob->toArray());
//    }

    function validateArguments($args)
    {
        if (!checkForValidArguments($args))
            throw new Exception("Invalid (null) arguments: " . print_r($args, true));

        if (!$args || count($args) <= 2) // need at least 2 parameters (class, method)
        {
            if (count($args) < 2)
                throw new Exception("No method name passed in arguments: " . print_r($args, true));

            if (count($args) < 1)
                throw new Exception("No service name passed in arguments: " . print_r($args, true));
        }
    }

    function checkForValidArguments($args)
    {
        if (!$args || count($args) <= 0)
            return false;

        foreach ($args as $argument)
        {
            if (strlen(trim($argument)) == 0)
                return false;
        }

        return true;
    }

?>