<?php

    import("aerialframework.core.AerialServer");

    $server = new AerialServer();
    $server->start();
?>