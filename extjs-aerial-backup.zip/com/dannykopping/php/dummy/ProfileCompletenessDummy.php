<?php

    class ProfileCompletenessDummy
    {
        public $total;
        public $profilePercentage;
        public $documentPercentage;
        public $videoPercentage;

        public $_explicitType = "za.co.rsajobs.dummy.ProfileCompletenessDummy";
    }
?>