<?php

    class BillingDummy
    {
        public $totalSpent;
        public $numPurchases;
        public $numCredits;

        public $_explicitType = "za.co.rsajobs.dummy.BillingDummy";
    }
?>