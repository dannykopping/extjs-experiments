<?php

    class DashboardDummy
    {
        // recruiter fields
        public $availableCredits;
        public $numInfoPacksPurchased;
        public $avgMatchesPerJobSpec;

        public $freshMatches;
        public $recentPurchases;

        public $purchasesCreditsGraph;

        // jobseeker fields
        public $profileViews;
        public $infoPackPurchases;
        public $matchQuality;

        public $_explicitType = "za.co.rsajobs.dummy.DashboardDummy";
    }
?>