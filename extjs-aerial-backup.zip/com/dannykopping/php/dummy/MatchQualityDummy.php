<?php

    class MatchQualityDummy
    {
        public $bad;
        public $good;
        public $excellent;

        public $_explicitType = "za.co.rsajobs.dummy.MatchQualityDummy";
    }
?>