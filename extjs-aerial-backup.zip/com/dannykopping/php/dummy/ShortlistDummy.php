<?php

    class ShortlistDummy
    {
        public $shortlist;
        public $purchasedUsers;

        public $_explicitType = "za.co.rsajobs.dummy.ShortlistDummy";
    }
?>