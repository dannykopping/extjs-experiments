<?php

    class ProfileViewDummy
    {
        public $totalViews;
        public $numJobSpecs;
        public $numCompanies;
        public $lastUpdate;

        public $_explicitType = "za.co.rsajobs.dummy.ProfileViewDummy";
    }
?>