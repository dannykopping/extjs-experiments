Ext.define('AM.store.Users', {
    extend: 'Ext.data.Store',
    model: 'AM.model.User',
    storeId: "userStore",
    requires: ["AM.proxy.AerialProxy"],

    proxy: {
        type: 'aerial',

        service: "UserService",
        method: "getUsersLike",

        api: {
            read: 'http://localhost/play/helloext/aerial/server/server.php',
            update: 'http://localhost/play/helloext/aerial/server/server.php'
        },
        reader: {
            type: 'json',
            root: 'data',
            successProperty: 'success'
        }
    },

    getUsersLike: function(options, params)
    {
        var proxy = this.getProxy();

        var paramArgs = [];
        for(var x = 1; x < arguments.length; x++)
            paramArgs.push(arguments[x]);

        proxy.parameters = proxy.encodeParameters(paramArgs);

        console.log(proxy.parameters);

        this.load(options);
    }
});